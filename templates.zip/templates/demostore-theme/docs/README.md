# Assemblers Appliance Theme
A simple example store implemented in Store Framework

Used in our demostore
## Preview
![](https://user-images.githubusercontent.com/484167/71480046-e9aa7080-27d5-11ea-9923-e5ad48891cec.png)
